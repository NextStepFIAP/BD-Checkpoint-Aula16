CREATE SEQUENCE seq_funcionario
start with 1
increment by 1;

CREATE SEQUENCE seq_telefone
start with 1
increment by 1;

CREATE SEQUENCE seq_proj
start with 1
increment by 1;

CREATE SEQUENCE seq_estado
start with 1
increment by 1;

CREATE SEQUENCE seq_cidade
start with 1
increment by 1;

CREATE SEQUENCE seq_bairro
start with 1
increment by 1;

CREATE SEQUENCE seq_endereco
start with 1
increment by 1;

CREATE SEQUENCE seq_end_func
start with 1
increment by 1;

CREATE TABLE t_sak_bairro (
    cd_bairro  NUMBER(4) NOT NULL,
    cd_cidade  NUMBER(3) NOT NULL,
    nm_bairro  VARCHAR2(100) NOT NULL
);

ALTER TABLE t_sak_bairro ADD CONSTRAINT pk_sak_bairro PRIMARY KEY ( cd_bairro );

CREATE TABLE t_sak_cidade (
    cd_cidade  NUMBER(3) NOT NULL,
    cd_estado  NUMBER(2) NOT NULL,
    nm_cidade  VARCHAR2(100) NOT NULL
);

ALTER TABLE t_sak_cidade ADD CONSTRAINT pk_sak_cidade PRIMARY KEY ( cd_cidade );

CREATE TABLE t_sak_dependente (
    cd_func        NUMBER(5) NOT NULL,
    id_dependente  NUMBER(3) NOT NULL,
    nm_dependente  VARCHAR2(50) NOT NULL,
    dt_nascimento  DATE NOT NULL,
    st_dependente  VARCHAR2(10) NOT NULL
);

ALTER TABLE t_sak_dependente
    ADD CONSTRAINT ck_sak_dependente_status CHECK ( st_dependente IN (
        'ATIVO',
        'INATIVO'
    ) );

ALTER TABLE t_sak_dependente ADD CONSTRAINT pk_sak_dependente PRIMARY KEY ( id_dependente,
                                                                            cd_func );

CREATE TABLE t_sak_depto (
    cd_depto  NUMBER(4) NOT NULL,
    nm_depto  VARCHAR2(60) NOT NULL,
    sg_depto  CHAR(3) NOT NULL
);

ALTER TABLE t_sak_depto ADD CONSTRAINT pk_sak_depto PRIMARY KEY ( cd_depto );

ALTER TABLE t_sak_depto ADD CONSTRAINT un_sak_depto_nome UNIQUE ( nm_depto );

CREATE TABLE t_sak_endereco (
    cd_end_correio  NUMBER NOT NULL,
    cd_bairro       NUMBER(4) NOT NULL,
    nr_cep          NUMBER(8) NOT NULL,
    ds_logradouro   VARCHAR2(150) NOT NULL
);

ALTER TABLE t_sak_endereco ADD CONSTRAINT pk_sak_endereco_correio PRIMARY KEY ( cd_end_correio );

CREATE TABLE t_sak_estado (
    cd_estado  NUMBER(2) NOT NULL,
    nm_estado  VARCHAR2(45) NOT NULL,
    sg_estado  CHAR(2) NOT NULL
);

ALTER TABLE t_sak_estado ADD CONSTRAINT pk_sak_estado PRIMARY KEY ( cd_estado );

CREATE TABLE t_sak_execucao_proj (
    cd_projeto          NUMBER(10) NOT NULL,
    cd_implantacao      NUMBER(3) NOT NULL,
    cd_func             NUMBER(5) NOT NULL,
    ds_papel_func_proj  VARCHAR2(100),
    dt_entrada          DATE NOT NULL,
    dt_saida            DATE
);

ALTER TABLE t_sak_execucao_proj ADD CONSTRAINT pk_sak_implantacao PRIMARY KEY ( cd_implantacao,
                                                                                cd_projeto );

CREATE TABLE t_sak_funcionario (
    cd_func          NUMBER(5) NOT NULL,
    cd_depto         NUMBER(4) NOT NULL,
    nm_funcionario   VARCHAR2(60) NOT NULL,
    dt_nascimento    DATE NOT NULL,
    ds_estado_civil  VARCHAR2(20),
    vl_salario       NUMBER(10, 2),
    dt_admissao      DATE NOT NULL
);

ALTER TABLE t_sak_funcionario ADD CONSTRAINT pk_sak_funcionario PRIMARY KEY ( cd_func );

CREATE TABLE t_sak_funcionario_endereco (
    cd_func           NUMBER(5) NOT NULL,
    cd_end_func       NUMBER(8) NOT NULL,
    cd_end_correio    NUMBER NOT NULL,
    cd_tipo_endereco  NUMBER(4) NOT NULL,
    ds_complemento    VARCHAR2(100) NULL,
    nr_logradouro     NUMBER(5) NOT NULL
);

ALTER TABLE t_sak_funcionario_endereco ADD CONSTRAINT pk_sak_funcionario_endereco PRIMARY KEY ( cd_end_func,
                                                                                                cd_func );

CREATE TABLE t_sak_projeto (
    cd_projeto         NUMBER(10) NOT NULL,
    nm_projeto         VARCHAR2(100) NOT NULL,
    vl_budget_projeto  NUMBER(10, 2) NOT NULL,
    dt_inicio          DATE NOT NULL,
    dt_termino         DATE
);

ALTER TABLE t_sak_projeto ADD CONSTRAINT pk_sak_projeto PRIMARY KEY ( cd_projeto );

ALTER TABLE t_sak_projeto ADD CONSTRAINT un_sak_projeto_nome UNIQUE ( nm_projeto );

CREATE TABLE t_sak_telefone (
    cd_func      NUMBER(5) NOT NULL,
    cd_telefone  NUMBER(3) NOT NULL,
    nr_ddd       NUMBER(3) NOT NULL,
    nr_telefone  NUMBER(8) NOT NULL
);

ALTER TABLE t_sak_telefone ADD CONSTRAINT pk_sak_telefone PRIMARY KEY ( cd_telefone,
                                                                        cd_func );

CREATE TABLE t_sak_tipo_endereco (
    cd_tipo_endereco  NUMBER(4) NOT NULL,
    nm_tipo_endereco  VARCHAR2(20) NOT NULL
);

ALTER TABLE t_sak_tipo_endereco ADD CONSTRAINT pk_sak_tipo_endereco PRIMARY KEY ( cd_tipo_endereco );

ALTER TABLE t_sak_endereco
    ADD CONSTRAINT fk_sak_bairro_endereco FOREIGN KEY ( cd_bairro )
        REFERENCES t_sak_bairro ( cd_bairro );

ALTER TABLE t_sak_bairro
    ADD CONSTRAINT fk_sak_cidade_bairro FOREIGN KEY ( cd_cidade )
        REFERENCES t_sak_cidade ( cd_cidade );

ALTER TABLE t_sak_funcionario
    ADD CONSTRAINT fk_sak_depto_func FOREIGN KEY ( cd_depto )
        REFERENCES t_sak_depto ( cd_depto );

ALTER TABLE t_sak_funcionario_endereco
    ADD CONSTRAINT fk_sak_end_correio_func FOREIGN KEY ( cd_end_correio )
        REFERENCES t_sak_endereco ( cd_end_correio );

ALTER TABLE t_sak_cidade
    ADD CONSTRAINT fk_sak_estado_cidade FOREIGN KEY ( cd_estado )
        REFERENCES t_sak_estado ( cd_estado );

ALTER TABLE t_sak_dependente
    ADD CONSTRAINT fk_sak_func_dependente FOREIGN KEY ( cd_func )
        REFERENCES t_sak_funcionario ( cd_func );

ALTER TABLE t_sak_funcionario_endereco
    ADD CONSTRAINT fk_sak_func_endereco FOREIGN KEY ( cd_func )
        REFERENCES t_sak_funcionario ( cd_func );

ALTER TABLE t_sak_execucao_proj
    ADD CONSTRAINT fk_sak_func_exec_proj FOREIGN KEY ( cd_func )
        REFERENCES t_sak_funcionario ( cd_func );

ALTER TABLE t_sak_telefone
    ADD CONSTRAINT fk_sak_func_telefone FOREIGN KEY ( cd_func )
        REFERENCES t_sak_funcionario ( cd_func );

ALTER TABLE t_sak_execucao_proj
    ADD CONSTRAINT fk_sak_proj_exec_proj FOREIGN KEY ( cd_projeto )
        REFERENCES t_sak_projeto ( cd_projeto );

ALTER TABLE t_sak_funcionario_endereco
    ADD CONSTRAINT fk_sak_tipo_endereco FOREIGN KEY ( cd_tipo_endereco )
        REFERENCES t_sak_tipo_endereco ( cd_tipo_endereco );
