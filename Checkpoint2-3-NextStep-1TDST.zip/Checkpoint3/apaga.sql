DROP SEQUENCE seq_bairro;
DROP SEQUENCE seq_cidade;
DROP SEQUENCE seq_end_func;
DROP SEQUENCE seq_endereco;
DROP SEQUENCE seq_estado;
DROP SEQUENCE seq_funcionario;
DROP SEQUENCE seq_proj;
DROP SEQUENCE seq_telefone;

DROP TABLE t_sak_bairro CASCADE CONSTRAINTS;

DROP TABLE t_sak_cidade CASCADE CONSTRAINTS;

DROP TABLE t_sak_dependente CASCADE CONSTRAINTS;

DROP TABLE t_sak_depto CASCADE CONSTRAINTS;

DROP TABLE t_sak_endereco CASCADE CONSTRAINTS;

DROP TABLE t_sak_estado CASCADE CONSTRAINTS;

DROP TABLE t_sak_execucao_proj CASCADE CONSTRAINTS;

DROP TABLE t_sak_funcionario CASCADE CONSTRAINTS;

DROP TABLE t_sak_funcionario_endereco CASCADE CONSTRAINTS;

DROP TABLE t_sak_projeto CASCADE CONSTRAINTS;

DROP TABLE t_sak_telefone CASCADE CONSTRAINTS;

DROP TABLE t_sak_tipo_endereco CASCADE CONSTRAINTS;


